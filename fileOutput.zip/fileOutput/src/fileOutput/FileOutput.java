package fileOutput;
import java.io.*;
public class FileOutput {

    public static void main(String[] args) {
        String[] testOrder = {"Cool 1","Cool 2","Cool 3","Cool 4","Cool 5","Cool 6","Cool 7"};
        String testID = "9739011010";
        try {
            outputFile(testID, testOrder);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    
    public static void outputFile(String orderID, String[] order) throws IOException
    {
        String path = "../fileOutput/src/exportedFiles/";
        File outputFile = new File(path+orderID+".txt");
        
        FileWriter output = new FileWriter(outputFile);
        try 
        {
        for(String pizza : order) {output.write(pizza+"\n");}
        }
        finally
        {
            output.close();
        }
    }

}

