package Pizzas;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

public class PepperoniTester {
    Pepperoni testPizza;
    ArrayList<Topping> testTop;
    @BeforeEach                                         
    void setUp() {
        testTop = new ArrayList<Topping>();
        testTop.add(Topping.PEPPERONI);
    }
    
    //Test Small 1 Topping Pepperoni
    @Test
    @DisplayName("Small Default Pepperoni Should be $8.99")
    void testSmall()
    {
        testPizza = new Pepperoni(Size.SMALL,testTop);
        assertEquals(8.99, testPizza.price());
    }
  //Test Medium 1 Topping Pepperoni
    @Test
    @DisplayName("Medium Default Pepperoni Should be $10.99")
    void testMed()
    {
        testPizza = new Pepperoni(Size.MEDIUM,testTop);
        assertEquals(10.99, testPizza.price());
    }
  //Test Large 1 Topping Pepperoni
    @Test
    @DisplayName("Large Default Pepperoni Should be $12.99")
    void testLarge()
    {
        testPizza = new Pepperoni(Size.LARGE,testTop);
        assertEquals(12.99, testPizza.price());
    }
    //Test Small 2 Topping Pepperoni
    @Test
    @DisplayName("Small 2 Topping Pepperoni Should be $10.48")
    void testTwoSmall()
    {
        testTop.add(Topping.BACON);
        testPizza = new Pepperoni(Size.SMALL,testTop);
        assertEquals(10.48, testPizza.price());
    }
    //Test Medium 2 Topping Pepperoni
    @Test
    @DisplayName("Medium 2 Topping Pepperoni Should be $12.48")
    void testTwoMed()
    {
        testTop.add(Topping.BACON);
        testPizza = new Pepperoni(Size.MEDIUM,testTop);
        assertEquals(12.48, testPizza.price());
    }
  //Test Large 2 Topping Pepperoni
    @Test
    @DisplayName("Large 2 Topping Pepperoni Should be $12.99")
    void testTwoLarge()
    {
        testTop.add(Topping.BACON);
        testPizza = new Pepperoni(Size.LARGE,testTop);
        assertEquals(14.48, testPizza.price());
    }
    //Test Small 7 Topping Pepperoni
    @Test
    @DisplayName("Small 7 Topping Pepperoni Should be $17.93")
    void testSevenSmall()
    {
        testTop.add(Topping.BACON);
        testTop.add(Topping.ONION);
        testTop.add(Topping.CHICKEN);
        testTop.add(Topping.SAUSAGE);
        testTop.add(Topping.JALAPENO);
        testTop.add(Topping.PEPPERS);
        testPizza = new Pepperoni(Size.SMALL,testTop);
        assertEquals(17.93, testPizza.price());
    }
    //Test Medium 7 Topping Pepperoni
    @Test
    @DisplayName("Medium 7 Topping Pepperoni Should be $19.93")
    void testSevenMed()
    {
        testTop.add(Topping.BACON);
        testTop.add(Topping.ONION);
        testTop.add(Topping.CHICKEN);
        testTop.add(Topping.SAUSAGE);
        testTop.add(Topping.JALAPENO);
        testTop.add(Topping.PEPPERS);
        testPizza = new Pepperoni(Size.MEDIUM,testTop);
        assertEquals(19.93, testPizza.price());
    }
  //Test Large 7 Topping Pepperoni
    @Test
    @DisplayName("Large 7 Topping Pepperoni Should be $21.93")
    void testSevenLarge()
    {
        testTop.add(Topping.BACON);
        testTop.add(Topping.ONION);
        testTop.add(Topping.CHICKEN);
        testTop.add(Topping.SAUSAGE);
        testTop.add(Topping.JALAPENO);
        testTop.add(Topping.PEPPERS);
        testPizza = new Pepperoni(Size.LARGE,testTop);
        assertEquals(21.93, testPizza.price());
    }
    //Test Small 0 Topping Pepperoni
    @Test
    @DisplayName("Small 0 Topping Pepperoni Should be $8.99")
    void testZeroSmall()
    {
        testTop.remove(Topping.PEPPERONI);
        testPizza = new Pepperoni(Size.SMALL,testTop);
        assertEquals(8.99, testPizza.price());
    }
  //Test Medium 0 Topping Pepperoni
    @Test
    @DisplayName("Medium 0 Topping Pepperoni Should be $10.99")
    void testZeroMed()
    {
        testTop.remove(Topping.PEPPERONI);
        testPizza = new Pepperoni(Size.MEDIUM,testTop);
        assertEquals(10.99, testPizza.price());
    }
  //Test Large 0 Topping Pepperoni
    @Test
    @DisplayName("Large 0 Topping Pepperoni Should be $12.99")
    void testZeroLarge()
    {
        testTop.remove(Topping.PEPPERONI);
        testPizza = new Pepperoni(Size.LARGE,testTop);
        assertEquals(12.99, testPizza.price());
    }
}
